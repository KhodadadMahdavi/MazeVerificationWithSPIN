#!/usr/bin/env bash
set -euo pipefail

# Run this inside MSYS2 UCRT64
# Expected tools on PATH: spin, gcc

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

mkdir -p trails

echo "[1/4] Generate verifier sources (spin -a)"
spin -a promela/maze.pml

echo "[2/4] Compile verifier (gcc -O2 -o pan pan.c)"
gcc -O2 -o pan pan.c

echo "[3/4] Run verifier (./pan -a -m100000)"
./pan -a -m100000 | tee trails/pan_output.txt

echo "[4/4] Copy pan.trail to trails/ (if exists)"
if [ -f pan.trail ]; then
  cp -f pan.trail trails/pan.trail
  echo "Trail copied to trails/pan.trail"
else
  echo "No pan.trail produced. Check trails/pan_output.txt"
fi
