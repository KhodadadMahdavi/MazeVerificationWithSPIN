# Run this in PowerShell from the project root
# Assumes you have Python on PATH

python scripts\00_check_solvable.py
python scripts\01_generate_pml.py
python scripts\03_parse_moves.py
python scripts\04_replay.py
