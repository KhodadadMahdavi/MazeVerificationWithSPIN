# Maze Verification with SPIN — Reproduction (M0)

This project reproduces the paper workflow for the **Maze** example:

**Level → PROMELA → SPIN (LTL: [](!win)) → counterexample trail → parse moves → replay**

## Folder Structure
- `levels/` sample level(s)
- `promela/` generated `maze.pml`
- `trails/` verifier output + trail replay text
- `moves/` parsed move sequence `U/D/L/R`
- `replay/` replay logs
- `scripts/` Python + MSYS2 helper scripts

## Prerequisites
### On Windows
- Python 3.11+ installed
- MSYS2 UCRT64 installed with `gcc`
- `spin` available on MSYS2 PATH (either `spin.exe` in `/ucrt64/bin` or a wrapper)

## Quick Start
### 1) PowerShell (generate PROMELA)
From project root:
```powershell
python scripts\00_check_solvable.py
python scripts\01_generate_pml.py
```

### 2) MSYS2 UCRT64 (run SPIN + produce trail)
From project root:
```bash
chmod +x scripts/02_run_spin_msys2.sh scripts/03_replay_trail_msys2.sh
./scripts/02_run_spin_msys2.sh
./scripts/03_replay_trail_msys2.sh
```

### 3) PowerShell (parse moves + replay)
```powershell
python scripts\03_parse_moves.py
python scripts\04_replay.py
```

If successful, you will see `WIN at step X` and `replay/replay_log.txt`.

## Notes
- The PROMELA model uses guarded nondeterministic choices (only legal moves are enabled) to keep the search tractable.
- LTL property: `ltl never_win { [](!win) }`.
  - If the level is solvable, SPIN finds a counterexample trail that reaches `win=true`.

## Versioning
Record your SPIN version by running:
```bash
spin -V
```